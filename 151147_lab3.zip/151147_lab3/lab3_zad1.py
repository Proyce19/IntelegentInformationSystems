import numpy as np
import pandas as pd
import networkx as nx
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn import feature_extraction, model_selection
def read_graph():
 # Load the graph from edgelist
 edgelist = pd.read_table("data/cora/cora.cites",
 header=None, names=["source", "target"])
 edgelist["label"] = "cites"
 graph = nx.from_pandas_edgelist(edgelist, edge_attr="label")
 nx.set_node_attributes(graph, "paper", "label")
 # Load the features and subject for the nodes
 feature_names = ["w_{}".format(ii) for ii in range(1433)]
 column_names = feature_names + ["subject"]
 node_data = pd.read_table("data/cora/cora.content",header=None, names=column_names)
 return graph, node_data, feature_names


g,nodes,features=read_graph()

#print("\nNodes: ",nodes)
#print("\nFeatures: ",features)
from matplotlib import pyplot as plt
plt.hist([x[1] for x in list(nx.degree(g))])
plt.show()
print("The community is: \n")
#so kodot prodolu se detektiraat zaednici vo grafot
#odzema povekje vreme za pecatenje
community=nx.algorithms.community.girvan_newman(g)
for i in next(community):
 print(i)
