import networkx as nx
G = nx.Graph()

G.add_node(1)
G.add_nodes_from([2,3])
H = nx.path_graph(10)
G.add_nodes_from(H)
G.add_edge(1,2)
#G.add_edge(2,1)
print(G.number_of_edges())
print(G.number_of_nodes())
print(G.adj)

print(G.degree[2])
