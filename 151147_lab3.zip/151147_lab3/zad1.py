import pandas as pd
import networkx as nx
from matplotlib import pyplot as plt
from networkx.algorithms import community as c
def read_graph():
 # Load the graph from edgelist
 edgelist = pd.read_table("data/cora/cora.cites",
 header=None, names=["source", "target"])
 edgelist["label"] = "cites"
 graph = nx.from_pandas_edgelist(edgelist, edge_attr="label")
 nx.set_node_attributes(graph, "paper", "label")
 # Load the features and subject for the nodes

 feature_names = ["w_{}".format(ii) for ii in range(1433)]
 column_names = feature_names + ["subject"]
 node_data = pd.read_table("data/cora/cora.content",header=None, names=column_names)
 return graph, node_data, feature_names

g,nd,fn = read_graph()

parts = c.girvan_newman(g)
#print(parts)


plt.axis("off")
spring_pos = nx.spring_layout(g)
nx.draw_networkx(g,pos=spring_pos,cmap=plt.get_cmap("jet"),node_color='red',node_size=35,with_labels=False)
plt.show()