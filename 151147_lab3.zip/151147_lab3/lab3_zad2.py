import numpy as np
import pandas as pd
import networkx as nx
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn import feature_extraction, model_selection
import random

from katz import katz
from random_walk import random_walk


def read_graph():
    # Load the graph from edgelist
    edgelist = pd.read_table("data/cora/cora.cites",
                             header=None, names=["source", "target"])
    edgelist["label"] = "cites"
    graph = nx.from_pandas_edgelist(edgelist, edge_attr="label")
    nx.set_node_attributes(graph, "paper", "label")

    # Load the features and subject for the nodes
    feature_names = ["w_{}".format(ii) for ii in range(1433)]
    column_names = feature_names + ["subject"]
    node_data = pd.read_table("data/cora/cora.content",
                              header=None, names=column_names)

    return graph, node_data, feature_names


def split_data(node_data):
    train_data, test_data = model_selection.train_test_split(node_data, train_size=0.7, test_size=None,
                                                             stratify=node_data['subject'])
    return train_data, test_data


def encode_classes(train_data, test_data):
    target_encoding = feature_extraction.DictVectorizer(sparse=False)

    train_targets = target_encoding.fit_transform(train_data[["subject"]].to_dict('records'))
    test_targets = target_encoding.transform(test_data[["subject"]].to_dict('records'))

    return train_targets, test_targets


def calculate_neighbors_class_features(graph, train_nodes, test_nodes, train_targets, test_targets):
    adjacency = nx.adjacency_matrix(graph).toarray()
    np.fill_diagonal(adjacency, val=0.0)
    indices = {x: i for i, x in enumerate(list(g.nodes()))}
    train_indices = [indices[node] for node in train_nodes]
    test_indices = [indices[node] for node in test_nodes]

    train_new_features = np.zeros(train_targets.shape)
    for i, node in enumerate(train_indices):
        values = adjacency[node]
        predicted_probs = np.sum(train_targets.T * values[train_indices], axis=1)
        train_new_features[i, :] = predicted_probs

    test_new_features = np.zeros(test_targets.shape)
    for i, node in enumerate(test_indices):
        values = adjacency[node]
        predicted_probs = np.sum(train_targets.T * values[train_indices], axis=1)
        test_new_features[i, :] = predicted_probs

    return train_new_features, test_new_features


def calculate_random_walk_features(graph, train_nodes, test_nodes, train_targets, test_targets):
    pass


def calculate_katz_features(graph, train_nodes, test_nodes, train_targets, test_targets):
    pass


def create_features(graph, train_nodes, test_nodes, train_targets, test_targets):
    # First order neighbors classes
    train_n, test_n = calculate_neighbors_class_features(graph, train_nodes, test_nodes,
                                                         train_targets, test_targets)
    # Random Walk
    train_pr, test_pr = calculate_random_walk_features(graph, train_nodes, test_nodes, train_targets, test_targets)
    # Katz
    train_k, test_k = calculate_katz_features(graph, train_nodes, test_nodes, train_targets, test_targets)

    return np.hstack((train_n, train_pr, train_k)), np.hstack((test_n, test_pr, test_k))


def calculate_metrics(test_targets, predictions):
    """Calculation of accuracy score, F1 micro and F1 macro"""
    print(f'\tAccuracy score: {accuracy_score(test_targets, predictions)}')
    print(f'\tF1-micro: {f1_score(test_targets, predictions, average="micro")}')
    print(f'\tF1-macro: {f1_score(test_targets, predictions, average="macro")}')


def classification_by_title(train_features, test_features, train_targets, test_targets):
    # ZADACA 2.1
    classifier = RandomForestClassifier(n_estimators=100, random_state=0)
    classifier.fit(train_features, train_targets)
    predicitons = classifier.predict(test_features)
    # print(predicitons.shape)
    #print("Random forest predictions: \n", predicitons)
    return predicitons


def classification_by_random_walk(graph, train_nodes, test_nodes, train_targets, test_targets):
    """Classification using only the values from Random Walk"""
    # ZADACA 2.2
    predicitons = classification_by_title(train_features, test_features, train_targets, test_targets)
    adjacency = nx.adjacency_matrix(graph, nodelist=graph.nodes(),
                                    weight=None).toarray()

    indices = {x: i for i, x in enumerate(list(graph.nodes()))}

    probabilities = random_walk(adjacency, 0)
    probabilities = probabilities.reshape(2708, 1)
    modifiedProbabilities = probabilities[0:1895, :]
    matrix7x1 = np.dot(train_targets.T, modifiedProbabilities)
    # print(matrix7x1)

    # modifikacija na test celite za da mozat da bidat presmetani metriki so 7x1 matricata
    import random
    # kolonata ja birame da e random
    l = random.randint(0, 812)
    modified7x1Test = test_targets.T[:, l:l + 1]
    # print(modified7x1Test)
    print("\nMetriki za celoto mnozestvo na test celi: \n")
    calculate_metrics(test_targets, predicitons)
    # normalizacija na 7x1 matricata
    normalized7x1Matrix = np.zeros((7, 1), np.float)
    for i in range(0, 7):
        for j in range(0, 1):
            if matrix7x1[i][j] >= 0.5:
                normalized7x1Matrix[i][j] = 1.0
            else:
                normalized7x1Matrix[i][j] = 0
    print("\nMetriki za mnozstvoto na test celi prilagodeni na matricata 7X1: \n")
    calculate_metrics(modified7x1Test, normalized7x1Matrix)


def classification_by_combined_features(graph, train_nodes, test_nodes, train_targets, test_targets):
    """Classification using combined features from the structure of the graph"""
    '''train_new_features, test_new_features = create_features(graph, train_nodes,
                                                            test_nodes, train_targets,
                                                            test_targets)'''
    # ZADACA 2.3
    adjacency = nx.adjacency_matrix(graph, nodelist=graph.nodes(),
                                    weight=None).toarray()
    train_new_features, test_new_features = calculate_neighbors_class_features(g, train_nodes, test_nodes,
                                                                               train_targets, test_targets)
    #print(train_new_features.shape, "\n")
    #print(test_new_features.shape, "\n")
    probabilitiesRW = random_walk(adjacency, 0)
    probabilitiesRW = probabilitiesRW.reshape(2708, 1)
    modifiedProbabilitiesRW = probabilitiesRW[0:1895, :]
    matrix7x1RW = np.dot(train_new_features.T, modifiedProbabilitiesRW)
    S, nodes = katz(graph)

    S_one = S[:, :1]

    modifiedProbabilitiesKatz = S[0:1895, :]
    matrix7x1Katz = np.dot(train_new_features.T, modifiedProbabilitiesKatz)
    #concatenated = np.vstack((matrix7x1RW, matrix7x1Katz))
    # print(concatenated)
    # print(S_one.shape)
    # print(nodes.shape)
    l2 = random.randint(0, 812)
    modified7x1TestNEW = test_new_features.T[:, l2:l2 + 1]
    # print(modified7x1Test)
    # print("\nMetriki za celoto mnozestvo na test celi: \n")
    # calculate_metrics(test_new_features, predicitons)

    # normalizacija na 7x1 matricata
    normalized7x1MatrixRW = np.zeros((7, 1), np.float)
    for i in range(0, 7):
        for j in range(0, 1):
            if matrix7x1RW[i][j] >= 0.5:
                normalized7x1MatrixRW[i][j] = 1.0
            else:
                normalized7x1MatrixRW[i][j] = 0

    print("RANDOM WALK: Metriki za modificiran test i normalizirana matrica")
    calculate_metrics(modified7x1TestNEW, normalized7x1MatrixRW)

    l3 = random.randint(0, 812)
    # modified7x1TestNEW = test_new_features.T[:, l2:l2 + 1]
    # print(modified7x1Test)
    # print("\nMetriki za celoto mnozestvo na test celi: \n")
    # calculate_metrics(test_new_features, predicitons)
    # normalizacija na 7x1 matricata
    normalized7x1MatrixKatz = np.zeros((7, 1), np.float)
    for i in range(0, 7):
        for j in range(0, 1):
            if matrix7x1Katz[i][j] >= 0.5:
                normalized7x1MatrixKatz[i][j] = 1.0
            else:
                normalized7x1MatrixKatz[i][j] = 0

    print("KATZ: Metriki za modificiran test i normalizirana matrica")
    calculate_metrics(modified7x1TestNEW, normalized7x1MatrixKatz)


if __name__ == '__main__':
    g, nodes, features_names = read_graph()
    train_data, test_data = split_data(nodes)
    train_targets, test_targets = encode_classes(train_data, test_data)
    train_features, test_features = train_data[features_names], test_data[features_names]
    train_nodes = train_features.index.values.tolist()
    test_nodes = test_features.index.values.tolist()
    print('Classification by title:')
    z=classification_by_title(train_features, test_features, train_targets, test_targets)
    print(z)
    print('Classification by random walks:')
    classification_by_random_walk(g, train_nodes, test_nodes, train_targets, test_targets)
    print('Classification by combined features:')
    classification_by_combined_features(g, train_nodes, test_nodes,
                                        train_targets, test_targets)
