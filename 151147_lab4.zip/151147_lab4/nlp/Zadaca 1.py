import json
import nltk
from sklearn.model_selection import train_test_split
from nltk.corpus import stopwords
from sklearn.metrics import accuracy_score,recall_score,f1_score
import numpy as np
#nltk.download('stopwords')
#Za klasifikacijata koristeni se 200 najfrekfentni zborovi
#Obemot e mal, so cel pobrzo izvrsuvanje na zadacata
def equalPositivesAndNegatives(arr1,arr2,arr3):
    counter=0
    ctr=0
    k=''
    l=''
    for i,j in arr2:
        for m,n in arr1:
            for x,y in arr3:
                if i==x and x!=m:


                 if x!=k and x!=l:
                        k=x
                        ctr+=1
                elif i==x and x==m:
                    ctr-=1
        if ctr >= 1:
            l=m
            counter = counter + 1
            ctr = 0

    return counter

def doesntHave(array,array2):
    counter=0
    list=[]
    globalcounter=0
    for i in range(0,len(array)):
        for j in range(0,len(array2)):
            if array[i][0] != array2[j][0]:
                counter=counter+1
            else:
                counter=counter-1
        if counter==len(array):

            globalcounter=globalcounter+1
        counter=0
    return globalcounter



def create_reviews_subset(file_name):
 reviews = list()
 s = [0, 0, 0, 0, 0]
 with open(file_name, 'r', encoding='utf-8') as doc:
    line = doc.readline()
    while line != '':
        review = json.loads(line)
        stars = review['stars']
        if s[int(stars) - 1] < 500:
            s[int(stars) - 1] += 1
            review_id = review['review_id']
            review_text = review['text']
            reviews.append({'Review_ID': review_id , 'Text': review_text, 'Stars':stars})
        line = doc.readline()
 with open('data/yelp_reviews_subset.json', 'w+', encoding='utf-8') as doc:
     json.dump(reviews, doc)


if __name__=="__main__":
    stopwords_en = set(stopwords.words("english"))

    with open('data/yelp_reviews_subset.json', 'r', encoding='utf-8') as doc:
        data = json.load(doc)

    train_data,test_data=train_test_split(data,train_size=0.8,test_size=0.2,random_state=0)
    negative=[]
    positive=[]
    #print(stopwords_en)
    all_words=[]
    for sentence in data:
        from nltk import word_tokenize
        words=word_tokenize(str(sentence))
        for w in words:

            all_words.append(w.lower())
            if w=='1.0' or w=='2.0' or w=='3.0':
                negative.append(sentence)
            elif w=='4.0' or w=='5.0':
                positive.append(sentence)


    all_words = nltk.FreqDist(all_words)
    top_ten = all_words.most_common(200)
    all_words_p=[]
    all_words_n=[]
    for sentence in positive:
        from nltk import word_tokenize
        words=word_tokenize(str(sentence))
        for w in words:
            if w not in stopwords_en:
                all_words_p.append(w.lower())
    for sentence in negative:
        from nltk import word_tokenize
        words=word_tokenize(str(sentence))
        for w in words:
            if w not in stopwords_en:
                all_words_n.append(w.lower())
    all_words_p=nltk.FreqDist(all_words_p)
    top_ten_p=all_words_p.most_common(200)
    all_words_n=nltk.FreqDist(all_words_n)
    top_ten_n=all_words_n.most_common(200)
    #target_train = []
    target_test = []
    all_words1=[]
    for sentence in train_data:
        from nltk import word_tokenize

        words = word_tokenize(str(sentence))
        for w in words:
            if w not in stopwords_en:
                all_words1.append(w.lower())
    all_words1=nltk.FreqDist(all_words1)
    top_ten1=all_words1.most_common(200)
    all_words2 = []
    for sentence in test_data:
        from nltk import word_tokenize

        words = word_tokenize(str(sentence))
        for w in words:
            if w not in stopwords_en:
                all_words2.append(w.lower())
    all_words2=nltk.FreqDist(all_words2)
    top_ten2=all_words1.most_common(200)
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import OneHotEncoder


    print("\nTOP 200 words : ",top_ten1)
    print("\nTOP 200 Positive : ",top_ten_p)
    print("\nTOP 200 Negative : ",top_ten_n)
    targetData = []
    for i, j in top_ten1:
        for m, n in top_ten_p:
            for x, y in top_ten_n:
                if i == m and m == x:
                    if y > n:
                        targetData.append(0)
                    else:
                        targetData.append(1)



    gcp1 = doesntHave(top_ten1,top_ten_p)
    gcn1 = doesntHave(top_ten1,top_ten_n)
    nr = equalPositivesAndNegatives(top_ten1,top_ten_p,top_ten_n)
    gcp1=gcp1-nr
    for i in range(0,gcp1):
        targetData.append(1)
    for i in range(0,gcn1):
        targetData.append(0)
    targetData2 = []
    for i in range(0,len(top_ten2)):
        for j in range(0,len(top_ten_p)):
            for k in range(0,len(top_ten_n)):
                if top_ten2[i][0] == top_ten_p[j][0] and top_ten2[i][0]==top_ten_n[k][0]:

                    if top_ten_p[j][1] < top_ten_n[k][1]:

                        targetData2.append(0)
                    else:
                        targetData2.append(1)






    gcp2 = doesntHave(top_ten2,top_ten_p)
    gcn2=doesntHave(top_ten2,top_ten_n)
    nr2 = equalPositivesAndNegatives(top_ten2,top_ten_p,top_ten_n)
    gcp2 = gcp2-nr2
    for i in range(0,gcp2):
        targetData2.append(1)
    for i in range(0,gcn2):
        targetData2.append(0)
    print(len(targetData))
    print(len(targetData2))

    classifier = RandomForestClassifier()
    targetData=np.reshape(targetData,(200,1))
    targetData2=np.reshape(targetData2,(200,1))
    top_ten1_indexes = []
    top_ten2_indexes = []
    for i in range(0,len(top_ten1)):
        for j in range(0,len(top_ten2)):
            if top_ten1[i][0]==top_ten2[j][0]:

                top_ten1_indexes.append(i)
                top_ten2_indexes.append(j)


    top_ten1_indexes=np.reshape(top_ten1_indexes,(200,1))
    top_ten2_indexes=np.reshape(top_ten2_indexes,(200,1))




    classifier.fit(top_ten1_indexes,targetData)
    predict = classifier.predict(top_ten2_indexes)
    print("Predicition: ",predict)


    print("The accuracy score is: ",accuracy_score(targetData2,predict))
    print("The macro score is: ",f1_score(targetData2,predict,average="macro"))
    print("The micro score is: ",f1_score(targetData2,predict,average="micro"))
    print("The recall is:",recall_score(targetData2,predict))


